<script>
	let value = "lorem ipsum"
	let count = 0;
	
	setInterval(() => {
		count += 1
	}, 100)
	
	$: double = count * 2
	
	$: tripple = double + count
</script>

<h1>Hello Anton {count} {double} {tripple}!</h1>
<input type="text" value={`${value}${count}`}>